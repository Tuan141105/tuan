from django.shortcuts import render
from products.models import Shoe

def index(request):
    featured_shoes = Shoe.objects.all().order_by('-created_at')[:6]
    categories = dict(Shoe.CATEGORIES)
    
    context = {
        'featured_shoes': featured_shoes,
        'categories': categories,
    }
    return render(request, 'main/index.html', context)
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from products.models import Shoe
from orders.models import Order, OrderItem

class OrderViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='12345')
        # Bỏ qua trường 'image' vì không bắt buộc trong test
        self.shoe = Shoe.objects.create(
            name="Test Shoe",
            brand="Test Brand",
            description="Comfortable and stylish",
            price=100.00,
            stock=10,
            size='42',
            category='running'
        )

    def test_checkout_view_success(self):
        url = reverse('orders:checkout') + f'?product_id={self.shoe.id}&quantity=2'
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'orders/orders_page.html')
        self.assertContains(response, 'Test Shoe')

    def test_checkout_view_fail(self):
        url = reverse('orders:checkout')
        response = self.client.get(url)
        self.assertRedirects(response, reverse('main:index'))

    def test_create_order_success(self):
        response = self.client.post(reverse('orders:create_order'), {
            'product_id': self.shoe.id,
            'quantity': 2,
            'full_name': 'Nguyen Van A',
            'email': 'a@example.com',
            'address': '123 ABC Street',
            'phone': '0901234567',
        })

        self.assertEqual(Order.objects.count(), 1)
        self.assertEqual(OrderItem.objects.count(), 1)
        self.assertEqual(Shoe.objects.get(id=self.shoe.id).stock, 8)
        order = Order.objects.first()
        self.assertRedirects(response, reverse('orders:order_success', args=[order.id]))

    def test_create_order_insufficient_stock(self):
        response = self.client.post(reverse('orders:create_order'), {
            'product_id': self.shoe.id,
            'quantity': 20,
            'full_name': 'Nguyen Van B',
            'email': 'b@example.com',
            'address': '456 DEF Street',
            'phone': '0909876543',
        })

        self.assertEqual(Order.objects.count(), 0)
        self.assertRedirects(response, reverse('products:product_detail', args=[self.shoe.id]))

    def test_order_success_view(self):
        order = Order.objects.create(
            full_name="Test User",
            email="test@example.com",
            address="123 Street",
            phone="0900000000",
            total_price=100.00
        )
        OrderItem.objects.create(
            order=order,
            shoe=self.shoe,
            quantity=1,
            price=100.00
        )
        url = reverse('orders:order_success', args=[order.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'orders/order_success.html')
        self.assertContains(response, 'Test User')

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Order, OrderItem
from products.models import Shoe
from django.urls import reverse

def checkout(request):
    # Giả sử sản phẩm được chọn được lưu trong session
    product_id = request.GET.get('product_id')
    quantity = int(request.GET.get('quantity', 1))
    
    if product_id:
        product = get_object_or_404(Shoe, id=product_id)
        total = product.price * quantity
        
        context = {
            'product': product,
            'quantity': quantity,
            'total': total,
        }
        return render(request, 'orders/orders_page.html', context)
    else:
        messages.error(request, "Không tìm thấy sản phẩm để thanh toán.")
        return redirect('main:index')

def create_order(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity = int(request.POST.get('quantity', 1))
        
        product = get_object_or_404(Shoe, id=product_id)
        
        # Kiểm tra số lượng tồn kho
        if product.stock < quantity:
            messages.error(request, "Không đủ số lượng sản phẩm trong kho.")
            return redirect('products:product_detail', product_id=product_id)
        
        # Tạo đơn hàng mới
        order = Order(
            full_name=request.POST.get('full_name'),
            email=request.POST.get('email'),
            address=request.POST.get('address'),
            phone=request.POST.get('phone'),
            total_price=product.price * quantity,
        )
        order.save()
        
        # Tạo chi tiết đơn hàng
        order_item = OrderItem(
            order=order,
            shoe=product,
            quantity=quantity,
            price=product.price
        )
        order_item.save()
        
        # Cập nhật số lượng tồn kho
        product.stock -= quantity
        product.save()
        
        return redirect('orders:order_success', order_id=order.id)
    
    return redirect('main:index')

def order_success(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    
    context = {
        'order': order,
    }
    return render(request, 'orders/order_success.html', context)
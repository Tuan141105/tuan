from django.db import models

class Shoe(models.Model):
    name = models.CharField(max_length=200)
    brand = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='images/shoes/')
    stock = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    SIZES = (
        ('35', '35'),
        ('36', '36'),
        ('37', '37'),
        ('38', '38'),
        ('39', '39'),
        ('40', '40'),
        ('41', '41'),
        ('42', '42'),
        ('43', '43'),
        ('44', '44'),
    )
    size = models.CharField(max_length=2, choices=SIZES)
    
    CATEGORIES = (
        ('running', 'Running'),
        ('casual', 'Casual'),
        ('sport', 'Sport'),
        ('formal', 'Formal'),
    )
    category = models.CharField(max_length=20, choices=CATEGORIES)
    
    def __str__(self):
        return f"{self.name} - {self.brand} - Size {self.size}"
from django.shortcuts import render, get_object_or_404
from .models import Shoe
from django.core.paginator import Paginator

def product_list(request):
    category = request.GET.get('category', '')
    
    if category:
        products = Shoe.objects.filter(category=category)
    else:
        products = Shoe.objects.all()
    
    paginator = Paginator(products, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    category_name = dict(Shoe.CATEGORIES).get(category, 'Tất cả sản phẩm')
    context = {
        'page_obj': page_obj,
        'categories': dict(Shoe.CATEGORIES),
        'selected_category': category,
        'category_name': category_name,
        'sizes': ['35','36','37','38','39','40','41','42','43','44'],  # thêm dòng này
    }
    return render(request, 'products/product_list.html', context)


def product_detail(request, product_id):
    product = get_object_or_404(Shoe, id=product_id)
    related_products = Shoe.objects.filter(category=product.category).exclude(id=product_id)[:4]
    
    context = {
        'product': product,
        'related_products': related_products,
    }
    return render(request, 'products/product_detail.html', context)

from django.test import TestCase
from products.models import Shoe
from django.core.files.uploadedfile import SimpleUploadedFile
import tempfile

class ShoeModelTest(TestCase):
    def test_create_shoe(self):
        # Tạo file ảnh giả
        image = SimpleUploadedFile("test.jpg", b"file_content", content_type="image/jpeg")

        shoe = Shoe.objects.create(
            name="Test Shoe",
            brand="Test Brand",
            description="A sample description.",
            price=999.99,
            image=image,
            stock=10,
            size='42',
            category='running'
        )
        
        self.assertEqual(shoe.name, "Test Shoe")
        self.assertEqual(shoe.brand, "Test Brand")
        self.assertEqual(shoe.price, 999.99)
        self.assertEqual(shoe.stock, 10)
        self.assertEqual(shoe.size, '42')
        self.assertEqual(shoe.category, 'running')
        self.assertTrue(shoe.image.name.startswith("images/shoes/") or shoe.image.name == "test.jpg")

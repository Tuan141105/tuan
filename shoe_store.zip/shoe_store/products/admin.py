from django.contrib import admin
from .models import Shoe

@admin.register(Shoe)
class ShoeAdmin(admin.ModelAdmin):
    list_display = ('name', 'brand', 'size', 'price', 'stock', 'category', 'created_at')
    list_filter = ('brand', 'category', 'size')
    search_fields = ('name', 'brand')
